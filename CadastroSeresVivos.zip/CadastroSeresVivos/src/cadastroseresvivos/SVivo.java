/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastroseresvivos;

public class SVivo {
	
	private String nome;
	private String localOrigem;
        private String reproducao;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getLocalOrigem() {
		return localOrigem;
	}
	public void setLocalOrigem(String localOrigem) {
		this.localOrigem = localOrigem;
	}  
        public String getReproducao() {
		return reproducao;
	}
	public void setReproducao(String reproducao) {
		this.reproducao = reproducao;
	}

}
